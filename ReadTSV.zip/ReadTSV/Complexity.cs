﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ReadTSV
{
    public enum Complexity
    {
        Simple,
            Moderate,
            Hazardous

    }
}
